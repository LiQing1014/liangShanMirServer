local tujian = {}

function main(self)

    sendluamsg(self, 10001, 1, 2, 3, {})

    release_print("hhhh")
end